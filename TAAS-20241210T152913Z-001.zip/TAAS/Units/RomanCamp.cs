﻿namespace TAAS.Units;

// Fonction Roman_Camp
public class RomanCamp
{
    // public  board 
    public Board Board; private const int n = 8; // set 
    public int Op=0 ; // init 
    
    // ethe main romanCamp board fun kita
    public RomanCamp(Board l) { Board = l; }

    // ethe main bool update kita
    public bool Update(int w)
    { if ((Board.lv) % (n* 2) == 1) // etthe main if kita 
        { int a = 0; // init
            while (a < Board.Height)
            { int p = Board.Random.NextMin(0, Board.Height);  // declar
                if (!(Board.Tls[p, w + 1].tile is Tile.River) && Board.Tls[p, w + 1].unit == null) // if kita 
                { Board.Tls[p, w + 1].unit = new Roman(Board); if (Board.Tls[p, w + 1].unit is Caesar) // fir board tile kita 
                    { return true; // true hogya
                    } return false; // false hogya
                } a++; // incrmt
            }
        } return false; // false hogya
    } }