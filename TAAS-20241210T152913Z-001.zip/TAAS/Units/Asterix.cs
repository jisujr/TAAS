﻿namespace TAAS.Units;

public class Asterix
{
    // ethe main public asterix board kita 
    public Board Board; public Asterix(Board a) { Board = a; }
    
    // ethe main bool update kita fir int h, int w kita 
    public bool Update(int h, int w)
    { 
        var a = new (int, int)[] { (-1, 0), (1, 0), (0, -1), (0, 1) }; // ethe main var kita 
        Queue<(int x, int y, List<(int, int)> path)> lv = new(); // etthe main queue use kita idk jeh lar sakhde par main lita 
        bool[,] b = new bool[h, w]; lv.Enqueue((h, w, new List<(int, int)>() { (h, w) })); b[h, w] = true; while (lv.Count > 0) // ethe main bool kita fir main lv kita 
        { var (yi, xi, p) = lv.Dequeue(); foreach (var (op, ox) in a) // ethe main var use kita 
            { int jass = yi + op; int jr = xi + ox; // ethe main int kita 
                if (jass >= 0 && jass < h && jr >= 0 && jr < w && !b[jass, jr] && Board.Tls[jass, jr].tile != Tile.River) { var patls = new List<(int, int)>(p) { (jass, jr) }; if (!UnitUtils.IsGaulish(Board.Tls[jass, jr].unit)) // ethe main if kita fir jass tehjr board tile kita 
                    { int loiv = Math.Min(2, patls.Count - 1); (int s, int t) = patls[loiv]; Amv(s, t, h, w); return true; } // ethe main int kita 
                    lv.Enqueue((jass, jr, patls)); b[jass, jr] = true; } } // ethe main lv .enqueue kita fir main lv kita 
        } return false; // rt false 
    }
    // public void amv function kita 
    private void Amv(int a, int b , int h, int w)
    { (int op, int lv) = (h, w); Board.Tls[op, lv].unit = null; Board.Tls[a, b].unit = this; // ethe main int lita fir int kita fir board kita 
        // ethe main move kita fir jass love kita fir new move kita 
        Move jas = new Move(Board.Tls[h, w].tile, this, h, w, Board.Tls[a, b].tile, Board.Tls[a, b].unit, a, b); Board.Moves.Push(jas); // ethe main mv kita 
    }
}