﻿namespace TAAS.Units;

public class UnitUtils
{
    //positionbounds fun 
    public static bool PositionInBounds(int h, int w)
    { if (h >= 0 && h < Board.Height && w >= 0 && w < Board.Width) return true; return false; // ethe main if kita fir main borad heignt use kar ke rt true kita teh rt false kita  
    }

    //Is Gaulish fun 
    public static bool IsGaulish(object unit)
    {
        if(unit is Asterix || unit is Obelix || unit is Idefix) return true; return false; // ethe main asterix teh obleix nu init kita fir idefix nu vi 
    }
}