﻿namespace TAAS.Units;

public class Caesar
{
    // ethe main ceasar kita constructor 
    public Caesar() { }

    //ehte main update kiti 
    public bool Update()
    {
        return false; // rt false kita ethe 
    }
}

    
