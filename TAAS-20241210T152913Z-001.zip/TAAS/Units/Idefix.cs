﻿namespace TAAS.Units;

// Fonction Idefix
public class Idefix
{ public Board Board; public Idefix(Board ip) { Board = ip;  }// asign it
    
    // Fonction Find
    public List<(int, int)> FindRightmostTargets()
    { var a = Board.Tls; List<(int, int)> tgs = new List<(int, int)>(); // init
        int cl = 19; while (cl >= 0) { int gol = 0; while (gol < 9)// init
            { var lv = a[gol, cl].unit; if (lv != null && !UnitUtils.IsGaulish(lv)) // declr
                { tgs.Add((gol, cl)); // add it
                }
                gol++;} // incremt
            cl--; // decremt
        } return tgs; // return 
    }

// Fonction Pick
    public (int, int) PickClosestTarget(List<(int, int)> units, int h, int w)
    { int zk = -1; int a = 0; // init
        while (a < units.Count) { if (units[a].Item2 > zk)
            { zk = units[a].Item2; // update it
            } a++; // incrmt
        } List<(int, int)> y = new List<(int, int)>(); a = 0; // init
        while (a < units.Count)
        {if (units[a].Item2 == zk) { y.Add(units[a]); // add it
            } a++; // incrmt
        } double dt = double.MaxValue; // declr
        (int po, int kh) = (-1, -1); a = 0; // init
        while (a < y.Count) { double li = Math.Sqrt(Math.Pow(y[a].Item1 - h, 2) + Math.Pow(y[a].Item2 - w, 2));
            if (li < dt) { dt = li; po = y[a].Item1; // chck krna
                kh = y[a].Item2; // fer chck krna
            } a++; // incrmt
        } return (po, kh); // return 
    }

    // Foncttion Valid
    public bool IsValidTile(int h, int w)
    { if (h < 0) { return false; // galt veh
        } if (h >= Board.Height) { return false; // galt veh
        } if (w < 0) { return false; // galt veh
        } if (w >= Board.Width) { return false; // galt veh
        } var love = Board.Tls[h, w]; // chok inf
        var loveip = love.tile; // vapis chk
        var lv = love.unit; // vapis chk
        if (loveip == Tile.River) { return false; // galt veh
        } if (lv is Idefix) { return false; // galt veh
        } if (lv is Asterix) { return false; // galt veh
        } if (lv is Obelix) { return false; // galt veh
        } return true; // great
    }

    // Fonction Updt
    public bool Update(int h, int w)
    { var trt = FindRightmostTargets(); if (trt.Count == 0) { return false; // galt veh
        } var (trt_h, trt_w) = PickClosestTarget(trt, h, w);
        int wh = h; int wd = w; // w
        if (trt_h < h)
        { if (IsValidTile(h - 1, w)) { wh = h - 1; // ute gya
            } 
        }else if (trt_h > h)
        { if (IsValidTile(h + 1, w)) { wh = h + 1; // thale gya
            } 
        }else if (trt_w > w)
        { if (trt_w - w == 1)
            { if (IsValidTile(h, w + 1))
                { wd = w + 1; // saje gya
                } 
            }else {if (IsValidTile(h, w + 2))
                { wd = w + 2; // do vari saje gya
                }
            }
        } else if (trt_w < w)
        { if (IsValidTile(h, w - 1)) { wd = w - 1; // khabe gya
            }
        } if (wh != h || wd != w)
        {
            Move jass = new Move(Board.Tls[h, w].tile, this, h, w, Board.Tls[wh, wd].tile, Board.Tls[wh, wd].unit, wh, wd); Board.Moves.Push(jass); Board.Tls[h, w].unit = null; Board.Tls[wh, wd].unit = this; // pta nhi ki veh
            h = wh; w = wd; // w
        } var lv = Board.Tls[h, w].unit; if (lv is Caesar) { return true; // succssss
        } return false; // nope
    }
}
