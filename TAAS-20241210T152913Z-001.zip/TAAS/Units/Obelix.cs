﻿namespace TAAS.Units;

//public class obleix 
public class Obelix
{ 
    // pûblic board fun kita 
    public Board Board; public Obelix(Board f) { Board = f; }

    // fun checkSurroundings 
    public (int, int) CheckSurroundings(int h, int w)
    {
        int a = Math.Max(h - 2, 0); int b = Math.Min(h + 2, Board.Height - 1); // int dclr kita fir int a teh int b declare kita 
        int x = Math.Max(w - 2, 0); int y = Math.Min(w + 2, Board.Width - 1); // ethe vi int kita x teh y dclr kita fir gogya 
        for (int i = a; i <= b; i++) // ethe main blc fo kita fir karke main fir ik bcl for kita 
        { 
            for (int s = x; s <= y; s++) // the main fir blc for kita 
            { var lv = Board.Tls[i, s].unit; if (lv is Roman || lv is RomanCamp || lv is Caesar) // ethe main var use kita lv 
                { return (i, s); } } } return (-1, -1); // ethe main rt (i, s ) kita fir rt -1 teh -1 ktia ki func chalpe 
    }
// func lookforcaesarposition
    public static (int, int) LookForCaesarPosition(Board board)
    {
        for (int m = 0; m < 9; m++) // ethe main for lita fir int use kita fir main fir for kita 
        { for (int r = 0; r < 20; r++) // ethe main for kita int kita fir board tiles kita 
            { if (board.Tls[m, r].unit is Caesar) { return (m, r); // ethe main rt m, r kita 
                } 
            } 
        } return (-1, -1); //ethe main rt -1 teh fir -1 rt kita 
    } // public bool update fun kita 
    public bool Update(int h, int w)
    { (int o,int p) = CheckSurroundings(h, w); bool raman = false; // ethe main int fir int p kita fir bool raman kita fir 
        if ((o, p) != (-1, -1)) // ethe main if kita fir main -1  teh -1 kita 
        { Move jass = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[o,p].tile, Board.Tls[o,p].unit,o,p); Board.Moves.Push(jass); Board.Tls[o, p].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null; } // ethe main move board tiles fir null kita fir move jass
        else { (o, p) = LookForCaesarPosition(Board);  // ethe main lookforceasarposition kita 
            if (w == 0 && o < h) // ethe vi main if kita 
            { if ((h - 1, w) == (o,p)) { raman = true; } // ethe main if kita fir rmn true kita 
                Move jassjr = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h-1,w].tile, Board.Tls[h-1,w].unit,h-1,w); Board.Moves.Push(jassjr); Board.Tls[h-1, w].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null;// ethe main move board tiles fir null kita fir move jass
            }else if (w == 0 && o > h) // ethe main if kita fir else if kita 
            { if ((o,p) == (h + 1, w)) { raman = true; }// ethe main if kita fir rmn true kita 
                Move lovejass = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h+1,w].tile, Board.Tls[h+1,w].unit,h+1,w); Board.Moves.Push(lovejass); Board.Tls[h+1, w].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null;// ethe main move board tiles fir null kita fir move jass
            }else { if ((o,p) == (h,w-1)) { raman = true; }// ethe main if kita fir else if kita 
                Move love = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h,w-1].tile, Board.Tls[h,w-1].unit,h,w-1); Board.Moves.Push(love); Board.Tls[h, w - 1].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null; }// ethe main move board tiles fir null kita fir move jass
        } return raman;// ethe main if kita fir rmn true kita
    }
}