﻿namespace TAAS.Units;

public class Roman
{

    public Board Board;
    public Roman(Board a) { Board = a; }// ethe main board nu board nal equal kita fir main update shuru kiti 
    public bool Update(int h, int w) // ethe main fun likhi 
    { if (w == 19) return true; // ethe main if karke fir rt true kita 
        if (UnitUtils.PositionInBounds(h, w + 1) && Board.Tls[h, w + 1].unit is null && Board.Tls[h, w + 1].tile is not Tile.River) // ethe main if kita fir main if else kita fir mlain sara initalise kita 
        { Board.Tls[h, w+1].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null; Move s = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h,w+1].tile, Board.Tls[h,w+1].unit,h,w+1); Board.Moves.Push(s);  //ehte main move use kita fir board tile use kita fir  borad tiles kitan
            if (w == 18) return true; } // rt true kita 
        else if (UnitUtils.PositionInBounds(h - 1, w + 1) && Board.Tls[h - 1, w + 1].unit is null && Board.Tls[h - 1, w + 1].tile is not Tile.River)// ethe main if kita fir main
        { Move t = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h-1,w+1].tile, Board.Tls[h-1,w+1].unit,h-1,w+1); Board.Moves.Push(t); Board.Tls[h-1, w+1].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null; //ehte main move use kita fir board tile use kita fir  borad tiles kitan
            if (w == 18) return true; }// rt true kita 
        else if (UnitUtils.PositionInBounds(h + 1, w + 1) && Board.Tls[h + 1, w + 1].unit is null && Board.Tls[h + 1, w + 1].tile is not Tile.River)// ethe main if kita fir main
        { Move p = new Move(Board.Tls[h,w].tile, this,h,w, Board.Tls[h +1 ,w+1].tile, Board.Tls[h +1,w+1].unit,h+1,w+1); Board.Moves.Push(p); Board.Tls[h+1, w+1].unit = Board.Tls[h, w].unit; Board.Tls[h, w].unit = null; //ehte main move use kita fir board tile use kita fir  borad tiles kitan
            if (w == 18) return true; } // rt true kita 
        return false; // rt false kita main 
    }
}