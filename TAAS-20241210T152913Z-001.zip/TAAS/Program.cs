﻿
using System.Formats.Asn1;
using TAAS;
using TAAS.Units;

Console.WriteLine("Hello, World!");

void Main()
{
    // Create an instance of the Program class
    Program program = new Program();

    // Run the tests
    RunTests();
}

void RunTests()
{
    // Test case 1
    RunTest(0, 9, 6734829, true); // Expected: True

    // Test case 2
    RunTest(2, 1, 278, false); // Expected: False

    // Test case 3
    RunTest(6, 5, 483902, true); // Expected: True

    // Test case 4
    RunTest(4, 4, 67398, true); // Expected: True

    // Test case 5
    RunTest(0, 0, 7489032, true); // Expected: True

    // Test case 6 (Random test)
    RunTest(1, 1, 8732, false); // Expected: False

    // Test case 7
    RunTest(5, 19, 9863278, true); // Expected: True

    // Test case 8
    RunTest(4, 12, 15945, true); // Expected: True

    // Test case 9
    RunTest(3, 7, 743892, true); // Expected: True
}

void RunTest(int h, int w, int seed, bool expected)
{
    Console.WriteLine($"Running Test: Start at ({h}, {w}) with seed {seed}");

    // Create the board instance using the seed
    Board board = new Board(seed);

    // Create Obelix and place it at the specified location
    Obelix obelix = new Obelix(board);
    board.Tiles[h, w].unit = obelix;

 

    // Perform the update
    bool result = obelix.Update(h, w);

    // Display the result of the update
    Console.WriteLine($"Update Result: {result}");
    Console.WriteLine($"Expected: {expected}");
        

    // Compare the result with the expected outcome
    if (result == expected)
    {
        Console.WriteLine("Test Passed!");
    }
    else
    {
        Console.WriteLine("Test Failed!");
    }
        
}
Main();