﻿// TAAS ਦੇ ਯੂਨਿਟਸ ਨੂੰ ਆਯਾਤ ਕਰਨਾ
using TAAS.Units;

namespace TAAS;

// ਬੋਰਡ ਕਲਾਸ ਦੀ ਘੋਸ਼ਣਾ
public class Board
{
    public const int Height = 9; // ਬੋਰਡ ਦੀ ਉਚਾਈ (ਲਾਈਨਾਂ ਦੀ ਗਿਣਤੀ)
    public const int Width = 20; // ਬੋਰਡ ਦੀ ਚੌੜਾਈ (ਕੋਲਮਾਂ ਦੀ ਗਿਣਤੀ)
    
    public int lv { get; set; } // ਮੌਜੂਦਾ ਪੱਧਰ ਜਾਂ ਟਰਨ ਸੰਭਾਲਨ ਵਾਲਾ ਗੁਣ

    public MyRandom Random { get; private set; } // ਰੈਂਡਮ ਨੰਬਰ ਜੈਨਰੇਟਰ ਦਾ ਆਬਜੈਕਟ

    public Stack<Move?> Moves { get; private set; } // ਚਲਾਂ ਨੂੰ ਸਟੋਰ ਕਰਨ ਲਈ ਸਟੈਕ
    public (Tile tile, object? unit)[,] Tls { get; private set; } // ਟਾਈਲਾਂ ਅਤੇ ਯੂਨਿਟਾਂ ਲਈ 2D ਐਰੇ

    // ਕਨਸਟ੍ਰਕਟਰ - ਬੋਰਡ ਸੈਟਅਪ ਕਰਦਾ ਹੈ
    public Board(int seed)
    {
        Random = new MyRandom(seed); // ਸੀਡ ਨਾਲ ਰੈਂਡਮ ਜੈਨਰੇਟਰ ਇਨਿਸ਼ੀਅਲਾਈਜ਼ ਕਰਨਾ
        lv = 0; // ਸ਼ੁਰੂਆਤੀ ਟਰਨ ਸੈਟ ਕਰਨਾ
        Moves = new Stack<Move?>(); // ਖਾਲੀ ਸਟੈਕ ਬਣਾਉਣਾ
        Tls = new (Tile tile, object? unit)[Height, Width]; // ਟਾਈਲਾਂ ਦਾ 2D ਐਰੇ ਬਣਾਉਣਾ
        for (int a = 0; a < 9; ++a) // ਹਰ ਲਾਈਨ ਵਿੱਚ ਟਾਈਲਾਂ ਪੂਰੀਆਂ ਕਰਨਾ
        {
            for (int b = 0; b < 20; b++) // ਹਰ ਕਾਲਮ ਵਿੱਚ ਟਾਈਲ ਪੂਰਣ ਲਈ
            {
                int x = Random.NextMin(0, 2); // 0 ਜਾਂ 1 ਲਈ ਰੈਂਡਮ ਨੰਬਰ ਜਨਰੇਟ ਕਰਨਾ
                Tls[a, b] = (x == 0) ? (Tile.Forest, null) : (Tile.Field, null); // ਫੋਰੇਸਟ ਜਾਂ ਫੀਲਡ ਟਾਈਲ ਐਸਾਈਨ ਕਰਨਾ
            }
        }
    }
    
    // ਬੋਰਡ ਦਿਖਾਉਣ ਵਾਲਾ ਫੰਕਸ਼ਨ
    public void raman()
    {
        Console.WriteLine($"Current Turn {lv} : {(lv % 2 == 0 ? "Gauls" : "Romans")}"); // ਮੌਜੂਦਾ ਟਰਨ ਅਤੇ ਖਿਡਾਰੀ ਦਿਖਾਉਣਾ

        Console.Write("  "); // ਸਪੇਸ ਦਾ ਪ੍ਰਿੰਟ
        for (int a = 0; a < Width; a++) // ਕਾਲਮ ਨੰਬਰ ਦਿਖਾਉਣਾ
            Console.Write($"{a, 2}"); 
        Console.WriteLine();
        for (int h = 0; h < Height; h++) // ਹਰੇਕ ਲਾਈਨ ਲਈ
        {
            Console.ResetColor(); // ਕਲਰ ਰੀਸੈਟ ਕਰੋ
            Console.Write($"{h} "); // ਲਾਈਨ ਨੰਬਰ ਦਿਖਾਉਣਾ
            for (int w = 0; w < Width; w++) // ਹਰੇਕ ਕਾਲਮ ਲਈ
            {
                var (k, opl) = Tls[h, w]; // ਟਾਈਲ ਅਤੇ ਯੂਨਿਟ ਪ੍ਰਾਪਤ ਕਰਨਾ
                switch(opl) // ਯੂਨਿਟ ਦੀ ਕਿਸਮ ਦੀ ਜਾਂਚ
                {
                    case Idefix: Console.ForegroundColor = ConsoleColor.Gray; Console.Write("ID"); break; // Idefix ਯੂਨਿਟ
                    case Roman: Console.ForegroundColor = ConsoleColor.DarkGray; Console.Write("RR"); break; // Roman ਯੂਨਿਟ
                    case RomanCamp: Console.ForegroundColor = ConsoleColor.DarkCyan; Console.Write("RC"); break; // RomanCamp ਯੂਨਿਟ
                    case Caesar: Console.ForegroundColor = ConsoleColor.DarkYellow; Console.Write("CC"); break; // Caesar ਯੂਨਿਟ
                    case Obelix: Console.ForegroundColor = ConsoleColor.Blue; Console.Write("OB"); break; // Obelix ਯੂਨਿਟ
                    case Asterix: Console.ForegroundColor = ConsoleColor.Red; Console.Write("AS"); break; // Asterix ਯੂਨਿਟ
                    case null: // ਜੇਕਰ ਟਾਈਲ ਖਾਲੀ ਹੈ
                        Console.ForegroundColor = k == Tile.Field ? ConsoleColor.Green : // ਫੀਲਡ ਟਾਈਲ
                                                  k == Tile.Forest ? ConsoleColor.DarkGreen : // ਫੋਰੇਸਟ ਟਾਈਲ
                                                  ConsoleColor.DarkBlue; // ਰਿਵਰ ਟਾਈਲ
                        Console.Write("\u2588\u2588"); // ਟਾਈਲ ਦੀ ਦਿਸ਼ਾ ਦਰਸਾਉਣ ਵਾਲਾ ਚਿੰਨ੍ਹ
                        break;
                }
            }
            Console.WriteLine(); // ਹਰ ਲਾਈਨ ਖਤਮ ਕਰਨ ਤੋਂ ਬਾਅਦ ਨਵੀਂ ਲਾਈਨ
        }
        Console.ResetColor(); // ਕਲਰ ਦੁਬਾਰਾ ਰੀਸੈਟ ਕਰੋ
    }

    // ਯੂਨਿਟਾਂ ਨੂੰ ਅਪਡੇਟ ਕਰਨ ਵਾਲਾ ਫੰਕਸ਼ਨ
    public bool amzing()
    {
        List<object> list = new List<object>(); // ਅਪਡੇਟ ਕੀਤੇ ਯੂਨਿਟਾਂ ਦੀ ਸੂਚੀ
        bool t = false; // ਚਾਲਾਂ ਦੀ ਸਥਿਤੀ
        for (int p = 0; p < Height; ++p) // ਹਰ ਲਾਈਨ ਲਈ
        {
            for (int j = 0; j < Width; ++j) // ਹਰ ਕਾਲਮ ਲਈ
            {
                object? ks = Tls[p, j].unit; // ਮੌਜੂਦਾ ਯੂਨਿਟ ਪ੍ਰਾਪਤ ਕਰਨਾ
                if (ks is not null && !list.Contains(ks)) // ਜੇ ਯੂਨਿਟ ਅਣਉਪਲਬਧ ਨਹੀਂ
                {
                    if (lv % 8 == 0 && lv != 0 && ks is RomanCamp po) { list.Add(ks); t = po.Update(j); } // RomanCamp ਅਪਡੇਟ
                    if (lv % 2 == 0) // ਜੇ Gauls ਦਾ ਟਰਨ ਹੈ
                    {
                        if (ks is Obelix to) { list.Add(ks); t = to.Update(p, j); } // Obelix ਅਪਡੇਟ
                        else if (ks is Idefix ti) { list.Add(ks); t = ti.Update(p, j); } // Idefix ਅਪਡੇਟ
                    }
                    else // ਜੇ Romans ਦਾ ਟਰਨ ਹੈ
                    {
                        if (ks is Caesar ci) { list.Add(ks); t = ci.Update(); } // Caesar ਅਪਡੇਟ
                        else if (ks is Roman kv) { list.Add(ks); t = kv.Update(p, j); } // Roman ਅਪਡੇਟ
                    }
                }
                if (t) { Moves.Push(null); return t; } // ਜੇ ਚਾਲ ਸਫਲ ਹੋਵੇ
            }
        }
        Moves.Push(null); // ਨਵਾਂ ਟਰਨ ਸ਼ੁਰੂ ਕਰਨ ਲਈ null ਚਾਲ ਦਾਖਲ ਕਰੋ
        lv++; // ਟਰਨ ਵਧਾਓ
        return t; // ਨਤੀਜਾ ਵਾਪਸ ਕਰੋ
    }

    // ਮੁਕਾਬਲਾ ਸੈਟ ਕਰਨ ਲਈ ਫੰਕਸ਼ਨ
    public void mov(Difficulty d)
    {
        if (d is Difficulty.Tinydefix) // ਜੇ ਮੁਸ਼ਕਲ ਤਾਈਨੀਡੇਫਿਕਸ ਹੈ
        {
            Tls[4, 0].unit = new Caesar(); // ਸਿਜ਼ਰ ਪੋਜ਼ੀਸ਼ਨ
            Tls[4, 2].unit = new RomanCamp(this); // ਰੋਮਨ ਕੈਂਪ ਪੋਜ਼ੀਸ਼ਨ
            Tls[2, 10].tile = Tile.River; Tls[4, 10].tile = Tile.River; Tls[6, 10].tile = Tile.River; // ਰਿਵਰ ਟਾਈਲਾਂ
            Tls[4, 19].unit = new Idefix(this); // ਆਈਡੇਫਿਕਸ ਪੋਜ਼ੀਸ਼ਨ
        }
        else if (d is Difficulty.Grobelix) // ਜੇ ਮੁਸ਼ਕਲ ਗਰੋਬੇਲਿਕਸ ਹੈ
        {
            // ਹਰੇਕ ਯੂਨਿਟ ਜਾਂ ਟਾਈਲ ਦਾ ਸੈਟਅਪ
            Tls[4, 0].unit = new Caesar(); // ਸਿਜ਼ਰ ਪੋਜ਼ੀਸ਼ਨ
            Tls[4, 2].unit = new RomanCamp(this); // ਰੋਮਨ ਕੈਂਪ ਪੋਜ਼ੀਸ਼ਨ
            Tls[2, 2].unit = new Roman(this); // ਰੋਮਨ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            Tls[3, 3].unit = new Roman(this); // ਰੋਮਨ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            Tls[4, 4].unit = new Roman(this); // ਰੋਮਨ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            Tls[5, 3].unit = new Roman(this); // ਰੋਮਨ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            Tls[6, 2].unit = new Roman(this); // ਰੋਮਨ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            for (int i = 9; i < 12; ++i) // ਰਿਵਰ ਟਾਈਲਾਂ ਸੈਟ ਕਰਨਾ
            {
                Tls[1, i].tile = Tile.River; // ਰਿਵਰ ਟਾਈਲ ਬਣਾਉਣਾ
                Tls[2, i].tile = Tile.River; // ਰਿਵਰ ਟਾਈਲ ਬਣਾਉਣਾ
                Tls[6, i].tile = Tile.River; // ਰਿਵਰ ਟਾਈਲ ਬਣਾਉਣਾ
                Tls[7, i].tile = Tile.River; // ਰਿਵਰ ਟਾਈਲ ਬਣਾਉਣਾ
            }

            Tls[3, 19].unit = new Obelix(this); // ਓਬੇਲਿਕਸ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
            Tls[4, 19].unit = new Idefix(this); // ਆਈਡੇਫਿਕਸ ਯੂਨਿਟ ਪੋਜ਼ੀਸ਼ਨ
        }
    }

    // ਚਲਾਂ ਨੂੰ ਵਾਪਸ ਕਰਨ ਲਈ ਮੈਥਡ
    public void oups()
    {
        if (Moves.Count != 0) // ਜੇ ਸਟੈਕ ਖਾਲੀ ਨਹੀਂ ਹੈ
        {
            // ਜੇ ਸਟੈਕ ਵਿੱਚ ਕੁਝ ਹੈ, ਇਹ null ਹੋਣਾ ਚਾਹੀਦਾ ਹੈ ਕਿਉਂਕਿ ਇਸ ਮੈਥਡ ਨੂੰ Board.PlayTurn() ਤੋਂ ਬਾਅਦ ਕਾਲ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ
            lv -= 1; // ਟਰਨ ਘਟਾਓ
            Moves.Pop(); // null ਚਾਲ ਹਟਾਓ
        }
        while (Moves.Count != 0 && Moves.Peek() != null) // ਜਦੋਂ ਤੱਕ ਸਟੈਕ ਵਿੱਚ ਚਾਲਾਂ ਹਨ
        {
            // ਚਾਲਾਂ ਨੂੰ ਹਟਾਉਣਾ ਜਦੋਂ ਤੱਕ ਟਰਨ ਦੀ ਸਿਰਜਨਾ ਨਾ ਹੋ ਜਾਵੇ
            Moves.Pop()!.UndoMove(this); // ਪਿਛਲੀ ਚਾਲ ਨੂੰ ਵਾਪਸ ਲਿਆਉਣਾ
        }
    }

    // ਸਾਰੇ ਚਲਾਂ ਨੂੰ ਪ੍ਰਿੰਟ ਕਰਨ ਵਾਲਾ ਮੈਥਡ
    public void terminal()
    {
        while (Moves.Count > 0) // ਜਦੋਂ ਤੱਕ ਸਟੈਕ ਖਾਲੀ ਨਹੀਂ ਹੋ ਜਾਂਦਾ
        {
            if (Moves.Peek() == null) // ਜੇ null ਚਾਲ ਹੈ
            {
                Console.WriteLine("null"); // null ਚਾਲ ਪ੍ਰਿੰਟ ਕਰੋ
                Moves.Pop(); // null ਚਾਲ ਹਟਾਓ
            }
            else
            {
                Moves.Pop()!.PrintMove(); // ਬਾਕੀ ਚਾਲਾਂ ਨੂੰ ਪ੍ਰਿੰਟ ਕਰੋ
            }
        }
    }
}
