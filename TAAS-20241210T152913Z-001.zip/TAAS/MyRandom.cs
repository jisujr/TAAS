﻿namespace TAAS;

public class MyRandom
{
    private int _seed;
    
    //my random fun 
    public MyRandom(int s) { _seed = s; }  // ethe main my random fun kita  
    
    // private int seed jehri ohna neh fun diti si 
    private int seed
    { get // ethe main get use kita 
        { _seed = (int)(Math.Abs(8944 * Math.Sqrt(_seed + 42)) % 5150757); return _seed; } // ethe main _seed nu math.abs teh main.sqrt use kita fir rt seed kita 
        set
        {
            _seed = value; // ethe main seed nu value dita 
        }
    }
    public int Next(int a = int.MaxValue) { return seed % a; } // ethe main maxvalue kita fir rt seed kita teh max kita 
    public int NextMin(int x, int y) { return seed % (y - x) + x; } // ethe main min valur kita fir main rt kita teh min value 
}