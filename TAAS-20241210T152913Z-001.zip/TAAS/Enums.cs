﻿namespace TAAS;

public enum Tile //ethe sare enum main write kite 
{
    Field, 
    River,
    Forest
}

public enum Difficulty // ethe vi main sare enum jerre rehnde si main write kite 
{
    Tinydefix,
    Grobelix,
    Megasterix
}