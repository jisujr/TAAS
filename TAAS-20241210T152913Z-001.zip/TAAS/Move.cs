﻿using System.Security.Cryptography;
using TAAS.Units;

namespace TAAS;
public class Move
{
    private ((Tile, object), (int, int)) mv_dt;
    private ((Tile, object?), (int, int)) tgt_dt;
    private Tile org_tl;
    private Tile dst_tl;
    private object mv_obj;
    private object? tgt_obj;
    private int org_h;
    private int org_w;
    private int dst_h;
    private int dst_w;

    public Move(Tile org_tl, object mv_obj, int org_h, int org_w, Tile dst_tl, object? tgt_obj, int dst_h, int dst_w)
    {
        this.org_tl = org_tl;
        this.dst_tl = dst_tl;
        this.mv_obj = mv_obj;
        this.tgt_obj = tgt_obj;
        this.org_h = org_h;
        this.org_w = org_w;
        this.dst_h = dst_h;
        this.dst_w = dst_w;
        mv_dt = ((this.org_tl, this.mv_obj), (this.org_h, this.org_w));
        tgt_dt = ((this.dst_tl, this.tgt_obj), (this.dst_h, this.dst_w));
    }

    public void UndoMove(Board b)
    {
        if (mv_obj is RomanCamp)
        {
            b.Tls[dst_h, dst_w].unit = null;
        }
        else
        {
            b.Tls[org_h, org_w].unit = mv_obj;
            b.Tls[dst_h, dst_w].unit = tgt_obj;
        }
    }

    public void PrintMove()
    {
        ((Tile org_tl, object mv_obj), (int org_h, int org_w)) = mv_dt;
        ((Tile dst_tl, object? tgt_obj), (int dst_h, int dst_w)) = tgt_dt;
        Console.WriteLine($"Moving: {mv_obj} from ({org_h},{org_w}) to Target: {tgt_obj} on ({dst_h},{dst_w}).");
    }
}